<footer>
     
    <p>&copy; <?php echo date('Y'); ?> My Custom Project Tracker</p><!-- Display the current year dynamically and site name -->
</footer>


<?php 
    wp_footer(); 
?>
</body>
</html>
